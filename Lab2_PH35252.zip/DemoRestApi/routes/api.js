var express = require('express');
var router = express.Router();

const Distributors = require('../models/distributors')
const Fruits = require('../models/fruits')

router.post('/add-distributor', async (req, res) => {
    try {
        const data = req.body;
        const newDistributors = new Distributors({
            name: data.name
        })
        const result = await newDistributors.save();
        if (result) {
            res.json({
                "status": 200,
                "messanger": "them thanh cong",
                "data": result
            })
        } else {
            res.json({
                "status": 400,
                "messenger": "loi, them khong thanh cong",
                "data": []
            })
        }
    } catch (err) {
        console.log(err);
    }
});

router.post('/add-fruit', async (req, res) => {
    try {
        const data = req.body;
        const newFruits = new Fruits({
            name: data.name,
            quantity: data.quantity,
            price: data.price,
            id_distributor: data.id_distributor
        })
        const result = await newFruits.save();
        if (result) {
            res.json({
                "status": 200,
                "messanger": "them thanh cong",
                "data": result
            })
        } else {
            res.json({
                "status": 400,
                "messenger": "loi, them khong thanh cong",
                "data": []
            })
        }
    } catch (err) {
        console.log(err);
    }
});

router.get('./get-list-fruit', async (req, res) => {
    try {
        const data = await Fruits.find().populate('id_distributor');
        res.json({
            "status": 200,
            "messanger": "ddanh sach fruit",
            "data": data
        })
    } catch (error) {
        console.log(error);
    }
})

module.exports = router;